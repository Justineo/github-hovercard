$(() => {
    'use strict';

    const GH_DOMAIN = location.host;

    const TOOLTIP_RELATED = '.tooltipster-base, .tooltipster-sizer';
    const DEFAULT_TARGET = document.body;
    let isExtracting = false;
    let observer = new MutationObserver(mutations => {
        if (isExtracting) {
            return;
        }
        mutations.forEach(mutation => {
            if (mutation.type === 'childList') {
                let target = mutation.target;
                if (!$(target).is(TOOLTIP_RELATED)
                    && !$(target).parents(TOOLTIP_RELATED).length
                    && !$(target).is(DEFAULT_TARGET)) {
                    extract(target);
                }
            }
        });
    });
    let observeConfig = {
        attributes: true,
        childList: true,
        characterData: true,
        subtree: true
    };
    observer.observe(DEFAULT_TARGET, observeConfig);

    let me = $('meta[name="user-login"]').attr('content');

    // based on octotree's config
    const GH_RESERVED_USER_NAMES = [
      'settings', 'orgs', 'organizations', 'site', 'blog', 'about',
      'explore', 'styleguide', 'showcases', 'trending', 'stars',
      'dashboard', 'notifications', 'search', 'developer', 'account',
      'pulls', 'issues', 'features', 'contact', 'security', 'join',
      'login', 'watching', 'new', 'integrations', 'pricing',
      'personal', 'business', 'open-source'
    ];

    const GH_RESERVED_REPO_NAMES = [
        'followers', 'following', 'repositories'
    ];

    const GH_USER_NAME_PATTERN = /^[a-z0-9]+$|^[a-z0-9](?:[a-z0-9](?!--)|-(?!-))*[a-z0-9]$/i;
    const GH_REPO_NAME_PATTERN = /^[a-z0-9\-_\.]+$/i;

    const TYPE_KEY = 'ghh-type';
    const VALUE_KEY = 'ghh-value';
    const EXTRACT_TYPE = {
        USER: 'user',
        REPO: 'repo',
        ISSUE: 'issue',
        SKIP: 'skip'
    };

    const EXTRACTOR = {
        SLUG: 1, // {{user}}/{{repo}}#{{issue}}
        TEXT_USER: 2, // {{user}}
        TITLE_USER: 3, // title="{{user}}"
        ALT_USER: 4, // alt="{{user}}"
        HREF_USER: 5, // href="{{user}}"
        URL: 6, // href="/{{user}}" or href="https://{{GH_DOMAIN}}/{{user}}"
        NEXT_TEXT_REPO: 7, // <span>...</span> {{repo}}
        ANCESTOR_URL_REPO: 8 // <a href="/{{user}}/{{repo}}">...{{elem}}...</a>
    };

    const GH_DOMAIN_PATTERN = GH_DOMAIN.replace(/\./g, '\\.');
    const URL_USER_PATTERN = `^https?:\\/\\/${GH_DOMAIN_PATTERN}\\/([^\\/\\?#]+)(?:[^\\/]*$|\\/(?:[\\?#]|$))`;
    const URL_REPO_PATTERN = `^https?:\\/\\/${GH_DOMAIN_PATTERN}\\/([^\\/\\?#]+)\\/([^\\/\\?#]+)(?:[^\\/]*$|\\/(?:[\\?#]|$))`;
    const URL_ISSUE_PATTERN = `^https?:\\/\\/${GH_DOMAIN_PATTERN}\\/([^\\/\\?#]+)\\/([^\\/\\?#]+)\\/(?:issues|pull)\\/(\\d+)(?:[^\\/]*$|(?:[\\?#]|$))`;
    const SLUG_PATTERN = /([^\/\s]+)\/([^#@\s]+)(?:#(\d+)|@[\da-f]+)?/;

    const STRATEGIES = {
        '.repo-list-name .prefix': EXTRACTOR.TEXT_USER,
        '.fork-flag a': EXTRACTOR.SLUG,
        '.avatar': EXTRACTOR.ALT_USER,
        '.gravatar': EXTRACTOR.ALT_USER,
        '.leaderboard-gravatar': EXTRACTOR.ALT_USER,
        '.author-gravatar': EXTRACTOR.ALT_USER,
        '.author-avatar': EXTRACTOR.ALT_USER,
        '.timeline-comment-avatar': EXTRACTOR.ALT_USER,
        '[data-ga-click~="target:actor"]': EXTRACTOR.TEXT_USER,
        '[data-ga-click~="target:repository"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:repo"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:parent"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:issue"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:issue-comment"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:pull"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:pull-comment"]': EXTRACTOR.SLUG,
        '[data-ga-click~="target:commit-comment"]': EXTRACTOR.SLUG,
        // '.user-mention': EXTRACTOR.TEXT_USER,
        '.opened-by a': EXTRACTOR.TEXT_USER,
        '.table-list-issues .issue-nwo-link': EXTRACTOR.SLUG,
        '.filter-list .repo-and-owner': EXTRACTOR.SLUG,
        '.repo-list a span:first-child': EXTRACTOR.TEXT_USER,
        '.repo-list .repo-name': EXTRACTOR.ANCESTOR_URL_REPO,
        '.repo-list-info a': EXTRACTOR.SLUG,
        '.repo-and-owner .owner': EXTRACTOR.TEXT_USER,
        '.repo-and-owner .repo': EXTRACTOR.ANCESTOR_URL_REPO,
        '.capped-card .aname': EXTRACTOR.TEXT_USER,
        '.team-member-username a': EXTRACTOR.TEXT_USER,
        '.member-username': EXTRACTOR.TEXT_USER,
        '.repo a:first-of-type': EXTRACTOR.TEXT_USER,
        '.repo a:last-of-type': EXTRACTOR.ANCESTOR_URL_REPO,
        '.repo-collection .repo-name': EXTRACTOR.SLUG,
        '.branch-meta a': EXTRACTOR.TEXT_USER,
        '.commit-meta .commit-author': EXTRACTOR.TEXT_USER,
        '.author-name a': EXTRACTOR.TEXT_USER,
        '.author-name span': EXTRACTOR.TEXT_USER,
        '.release-authorship a:first-of-type': EXTRACTOR.TEXT_USER,
        '.table-list-cell-avatar img': EXTRACTOR.ALT_USER,
        '.author': EXTRACTOR.TEXT_USER,
        '.codesearch-results .repo-list-name a': EXTRACTOR.SLUG,
        '.code-list-item > a ~ .title a:first-child': EXTRACTOR.SLUG,
        '.issue-list-meta li:first-child a': EXTRACTOR.SLUG,
        '.issue-list-meta li:nth-child(2) a': EXTRACTOR.TEXT_USER,
        '.user-list-info a:first-child': EXTRACTOR.TEXT_USER,
        '.commits li span': EXTRACTOR.TITLE_USER,
        '.follow-list-name a': EXTRACTOR.HREF_USER,
        '.sidebar-assignee .assignee': EXTRACTOR.TEXT_USER,
        '.contribution .cmeta': EXTRACTOR.SLUG,
        '.select-menu-item-gravatar img': EXTRACTOR.ALT_USER,
        '.notifications-repo-link': EXTRACTOR.SLUG,
        '.explore-page .repo-list-name .slash': EXTRACTOR.NEXT_TEXT_REPO,
        '.collection-page .repo-list-name .slash': EXTRACTOR.NEXT_TEXT_REPO,
        '.leaderboard-list-content .repo': EXTRACTOR.ANCESTOR_URL_REPO,
        '.profilecols .repo-list-name a': EXTRACTOR.ANCESTOR_URL_REPO,
        '.conversation-list-heading:has(.octicon-git-commit) + .simple-conversation-list a': EXTRACTOR.SLUG,
        '.discussion-item-ref strong': EXTRACTOR.SLUG,
        'a': EXTRACTOR.URL
    };

    const BLACK_LIST_SELECTOR = [
        '.ghh a',
        '.repo-nav a',
        '.tabnav-tab',
        '.discussion-item .timestamp',
        '.file-wrap a',
        '.reponav-item' // new UI
    ].join(', ');

    // Octicons in SVG
    const OCTICONS = {"alert":{"width":16,"height":16,"d":"M15.72 12.5l-6.85-11.98C8.69 0.21 8.36 0.02 8 0.02s-0.69 0.19-0.87 0.5l-6.85 11.98c-0.18 0.31-0.18 0.69 0 1C0.47 13.81 0.8 14 1.15 14h13.7c0.36 0 0.69-0.19 0.86-0.5S15.89 12.81 15.72 12.5zM9 12H7V10h2V12zM9 9H7V5h2V9z"},"arrow-right":{"width":10,"height":16,"d":"M10 8L4 3v3H0v4h4v3L10 8z"},"code":{"width":14,"height":16,"d":"M9.5 3l-1.5 1.5 3.5 3.5L8 11.5l1.5 1.5 4.5-5L9.5 3zM4.5 3L0 8l4.5 5 1.5-1.5L2.5 8l3.5-3.5L4.5 3z"},"diff":{"width":14,"height":16,"d":"M6 7h2v1H6v2h-1V8H3v-1h2V5h1v2zM3 13h5v-1H3v1z m4.5-11l3.5 3.5v9.5c0 0.55-0.45 1-1 1H1c-0.55 0-1-0.45-1-1V3c0-0.55 0.45-1 1-1h6.5z m2.5 4L7 3H1v12h9V6zM8.5 0S3 0 3 0v1h5l4 4v8h1V4.5L8.5 0z"},"git-commit":{"width":14,"height":16,"d":"M10.86 7c-0.45-1.72-2-3-3.86-3s-3.41 1.28-3.86 3H0v2h3.14c0.45 1.72 2 3 3.86 3s3.41-1.28 3.86-3h3.14V7H10.86zM7 10.2c-1.22 0-2.2-0.98-2.2-2.2s0.98-2.2 2.2-2.2 2.2 0.98 2.2 2.2-0.98 2.2-2.2 2.2z"},"git-pull-request":{"width":12,"height":16,"d":"M11 11.28c0-1.73 0-6.28 0-6.28-0.03-0.78-0.34-1.47-0.94-2.06s-1.28-0.91-2.06-0.94c0 0-1.02 0-1 0V0L4 3l3 3V4h1c0.27 0.02 0.48 0.11 0.69 0.31s0.3 0.42 0.31 0.69v6.28c-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72z m-1 2.92c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2zM4 3c0-1.11-0.89-2-2-2S0 1.89 0 3c0 0.73 0.41 1.38 1 1.72 0 1.55 0 5.56 0 6.56-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72V4.72c0.59-0.34 1-0.98 1-1.72z m-0.8 10c0 0.66-0.55 1.2-1.2 1.2s-1.2-0.55-1.2-1.2 0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2z m-1.2-8.8c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z"},"info":{"width":14,"height":16,"d":"M6.3 5.69c-0.19-0.19-0.28-0.42-0.28-0.7s0.09-0.52 0.28-0.7 0.42-0.28 0.7-0.28 0.52 0.09 0.7 0.28 0.28 0.42 0.28 0.7-0.09 0.52-0.28 0.7-0.42 0.3-0.7 0.3-0.52-0.11-0.7-0.3z m1.7 2.3c-0.02-0.25-0.11-0.48-0.31-0.69-0.2-0.19-0.42-0.3-0.69-0.31h-1c-0.27 0.02-0.48 0.13-0.69 0.31-0.2 0.2-0.3 0.44-0.31 0.69h1v3c0.02 0.27 0.11 0.5 0.31 0.69 0.2 0.2 0.42 0.31 0.69 0.31h1c0.27 0 0.48-0.11 0.69-0.31 0.2-0.19 0.3-0.42 0.31-0.69h-1V7.98z m-1-5.69C3.86 2.3 1.3 4.84 1.3 7.98s2.56 5.7 5.7 5.7 5.7-2.55 5.7-5.7-2.56-5.69-5.7-5.69m0-1.31c3.86 0 7 3.14 7 7S10.86 14.98 7 14.98 0 11.86 0 7.98 3.14 0.98 7 0.98z"},"issue-closed":{"width":16,"height":16,"d":"M7 10h2v2H7V10z m2-6H7v5h2V4z m1.5 1.5l-1 1 2.5 2.5 4-4.5-1-1-3 3.5-1.5-1.5zM8 13.7c-3.14 0-5.7-2.56-5.7-5.7s2.56-5.7 5.7-5.7c1.83 0 3.45 0.88 4.5 2.2l0.92-0.92C12.14 2 10.19 1 8 1 4.14 1 1 4.14 1 8s3.14 7 7 7 7-3.14 7-7l-1.52 1.52c-0.66 2.41-2.86 4.19-5.48 4.19z"},"issue-opened":{"width":14,"height":16,"d":"M7 2.3c3.14 0 5.7 2.56 5.7 5.7S10.14 13.7 7 13.7 1.3 11.14 1.3 8s2.56-5.7 5.7-5.7m0-1.3C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7S10.86 1 7 1z m1 3H6v5h2V4z m0 6H6v2h2V10z"},"link":{"width":16,"height":16,"d":"M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"},"location":{"width":12,"height":16,"d":"M6 0C2.69 0 0 2.5 0 5.5c0 4.52 6 10.5 6 10.5s6-5.98 6-10.5C12 2.5 9.31 0 6 0z m0 14.55C4.14 12.52 1 8.44 1 5.5 1 3.02 3.25 1 6 1c1.34 0 2.61 0.48 3.56 1.36 0.92 0.86 1.44 1.97 1.44 3.14 0 2.94-3.14 7.02-5 9.05z m2-9.05c0 1.11-0.89 2-2 2s-2-0.89-2-2 0.89-2 2-2 2 0.89 2 2z"},"organization":{"width":14,"height":16,"d":"M4.75 4.95c0.55 0.64 1.34 1.05 2.25 1.05s1.7-0.41 2.25-1.05c0.34 0.63 1 1.05 1.75 1.05 1.11 0 2-0.89 2-2s-0.89-2-2-2c-0.41 0-0.77 0.13-1.08 0.33C9.61 1 8.42 0 7 0S4.39 1 4.08 2.33c-0.31-0.2-0.67-0.33-1.08-0.33-1.11 0-2 0.89-2 2s0.89 2 2 2c0.75 0 1.41-0.42 1.75-1.05z m5.2-1.52c0.2-0.38 0.59-0.64 1.05-0.64 0.66 0 1.2 0.55 1.2 1.2s-0.55 1.2-1.2 1.2-1.17-0.53-1.19-1.17c0.06-0.19 0.11-0.39 0.14-0.59zM7 0.98c1.11 0 2.02 0.91 2.02 2.02s-0.91 2.02-2.02 2.02-2.02-0.91-2.02-2.02S5.89 0.98 7 0.98zM3 5.2c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2c0.45 0 0.84 0.27 1.05 0.64 0.03 0.2 0.08 0.41 0.14 0.59-0.02 0.64-0.53 1.17-1.19 1.17z m10 0.8H1c-0.55 0-1 0.45-1 1v3c0 0.55 0.45 1 1 1v2c0 0.55 0.45 1 1 1h1c0.55 0 1-0.45 1-1v-1h1v3c0 0.55 0.45 1 1 1h2c0.55 0 1-0.45 1-1V12h1v1c0 0.55 0.45 1 1 1h1c0.55 0 1-0.45 1-1V11c0.55 0 1-0.45 1-1V7c0-0.55-0.45-1-1-1zM3 13h-1V10H1V7h2v6z m7-2h-1V9h-1v6H6V9h-1v2h-1V7h6v4z m3-1h-1v3h-1V7h2v3z"},"person":{"width":8,"height":16,"d":"M7 6H1c-0.55 0-1 0.45-1 1v5h2v3c0 0.55 0.45 1 1 1h2c0.55 0 1-0.45 1-1V12h2V7c0-0.55-0.45-1-1-1z m0 5h-1V9h-1v6H3V9h-1v2H1V7h6v4z m0-8C7 1.34 5.66 0 4 0S1 1.34 1 3s1.34 3 3 3 3-1.34 3-3zM4 5c-1.11 0-2-0.89-2-2S2.89 1 4 1s2 0.89 2 2-0.89 2-2 2z"},"repo-forked":{"width":10,"height":16,"d":"M8 1c-1.11 0-2 0.89-2 2 0 0.73 0.41 1.38 1 1.72v1.28L5 8 3 6v-1.28c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2S0 1.89 0 3c0 0.73 0.41 1.38 1 1.72v1.78l3 3v1.78c-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72V9.5l3-3V4.72c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2zM2 4.2c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3 10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3-10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z"},"repo":{"width":12,"height":16,"d":"M4 9h-1v-1h1v1z m0-3h-1v1h1v-1z m0-2h-1v1h1v-1z m0-2h-1v1h1v-1z m8-1v12c0 0.55-0.45 1-1 1H6v2l-1.5-1.5-1.5 1.5V14H1c-0.55 0-1-0.45-1-1V1C0 0.45 0.45 0 1 0h10c0.55 0 1 0.45 1 1z m-1 10H1v2h2v-1h3v1h5V11z m0-10H2v9h9V1z"}};

    function getIcon(type, scale) {
        scale = scale || 1;
        var icon = OCTICONS[type];
        return `<svg class="octicon" width="${icon.width * scale}" height="${icon.height * scale}"
            viewBox="0 0 ${icon.width} ${icon.height}"><path d="${icon.d}" /></svg>`;
    }

    const CARD_TPL = {
        user: `
            <address class="ghh">
                <img src="{{avatar}}&s=32" class="ghh-avatar">
                <div class="ghh-person">
                    <p><strong><a href="{{userUrl}}">{{loginName}}</a></strong>{{#isAdmin}} (Staff){{/isAdmin}}{{#isOrg}} <small>(Organization)</small>{{/isOrg}}</p>
                    {{#realName}}<p>{{realName}}</p>{{/realName}}
                </div>
                <div class="ghh-more">
                    {{^isOrg}}<div class="ghh-stats">
                        <a href="{{followersUrl}}">
                            <strong>{{followers}}</strong>
                            <span>Followers</span>
                        </a>
                        <a href="{{followingUrl}}">
                            <strong>{{following}}</strong>
                            <span>Following</span>
                        </a>
                        <a href="{{reposUrl}}">
                            <strong>{{repos}}</strong>
                            <span>Repos</span>
                        </a>
                    </div>{{/isOrg}}
                    {{#location}}<p>{{{icons.location}}}</span>{{location}}</p>{{/location}}
                    {{#company}}<p>{{{icons.organization}}}{{company}}</p>{{/company}}
                </div>
            </address>`,
        repo: `
            <div class="ghh">
                <div class="ghh-repo">
                    {{{icons.repo}}}
                    <p><a href="{{ownerUrl}}">{{owner}}</a> / <strong><a href="{{repoUrl}}">{{repo}}</a></strong></p>
                    {{#parent}}<p><span>forked from <a href="{{url}}">{{repo}}</a></span></p>{{/parent}}
                </div>
                <div class="ghh-more">
                    <div class="ghh-stats">
                        <a href="{{starsUrl}}">
                            <strong>{{stars}}</strong>
                            <span>Stars</span>
                        </a>
                        <a href="{{forksUrl}}">
                            <strong>{{forks}}</strong>
                            <span>Forks</span>
                        </a>
                        {{#hasIssues}}<a href="{{issuesUrl}}">
                            <strong>{{issues}}</strong>
                            <span>Issues</span>
                        </a>{{/hasIssues}}
                    </div>
                    {{#desc}}<p class="ghh-repo-desc">{{{icons.info}}}{{{.}}}</p>{{/desc}}
                    {{#homepage}}<p>{{{icons.link}}}<a href="{{.}}">{{.}}</a></p>{{/homepage}}
                    {{#language}}<p>{{{icons.code}}}{{.}}</p>{{/language}}
                </div>
            </div>`,
        issue: `
            <div class="ghh">
                <div class="ghh-issue">
                    <p><span class="issue-number">#{{number}}</span> <a href="{{issueUrl}}"><strong>{{title}}</strong></a></p>
                </div>
                <div class="ghh-issue-meta">
                    <p><span class="state state-{{state}}">{{{icons.state}}}{{state}}</span><a href="{{userUrl}}">{{user}}</a> created on {{{createTime}}}</p>
                </div>
                {{#isPullRequest}}<div class="ghh-pull-meta">
                    <p>{{{icons.commit}}} {{commits}} commit{{^isSingleCommit}}s{{/isSingleCommit}}{{{icons.diff}}} {{changedFiles}} file{{^isSingleFile}}s{{/isSingleFile}} changed
                    <span class="diffstat">
                        <span class="text-diff-added">+{{additions}}</span>
                        <span class="text-diff-deleted">−{{deletions}}</span>
                    </span></p>
                    <p class="ghh-branch"><span class="commit-ref" title="{{headUser}}:{{headRef}}"><span class="user">{{headUser}}</span>:{{headRef}}</span><span>{{{icons.arrow}}}</span><span class="commit-ref" title="{{baseUser}}:{{baseRef}}"><span class="user">{{baseUser}}</span>:{{baseRef}}</span></p>
                </div>{{/isPullRequest}}
                {{#body}}<div class="ghh-issue-body">{{{.}}}</div>{{/body}}
            </div>`,
        error: `
            <div class="ghh ghh-error">
                <p><strong>{{{icons.alert}}}{{title}}</strong></p>
                {{#message}}<p>{{{message}}}</p>{{/message}}
            </div>`,
        form: `
            <div class="ghh-overlay">
                <form>
                    <p>
                        <input class="ghh-token" type="text" placeholder="Paste access token here..." size="40" />
                        <button class="btn btn-primary ghh-save">Save</button>
                        <button class="btn ghh-cancel">Cancel</button>
                    </p>
                </form>
            </div>`
    };

    const CREATE_TOKEN_PATH = `//${GH_DOMAIN}/settings/tokens/new`;
    const IS_ENTERPRISE = GH_DOMAIN !== 'github.com';
    const API_PREFIX = IS_ENTERPRISE ? `//${GH_DOMAIN}/api/v3/` : `//api.${GH_DOMAIN}/`;

    function trim(str) {
        if (!str) {
            return '';
        }
        return str.replace(/^\s+|\s+$/g, '');
    }

    function markExtracted(elem, type, value) {
        if (value) {
            elem.data(TYPE_KEY, type);
            elem.data(VALUE_KEY, value);
            elem.addClass(getTypeClass(type));
        }
        if (!type || !value) {
            elem.data(TYPE_KEY, EXTRACT_TYPE.SKIP);
        }
    }

    function getExtracted(elem) {
        let extractedSelector = Object.keys(EXTRACT_TYPE)
            .map(key => EXTRACT_TYPE[key])
            .map(getTypeClass)
            .map(className => `.${className}`)
            .join(',');
        return elem.data(VALUE_KEY) || elem.data(TYPE_KEY) === EXTRACT_TYPE.SKIP
            || elem.find(extractedSelector).length;
    }

    function getTypeClass(type) {
        return `ghh-${type}-x`;
    }

    function getFullRepoFromAncestorLink(elem) {
        let href = elem.closest('a').prop('href');
        let fullRepo = null;
        if (href) {
            let match = href.match(URL_REPO_PATTERN);
            fullRepo = match && (match[1] + '/' + match[2]);
        }
        return fullRepo;
    }

    function formatNumber(num) {
        if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'k';
        }
        return num;
    }

    const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    function formatTime(time) {
        let t = new Date(time);
        let formatted = MONTH_NAMES[t.getMonth()] + ' ' + t.getDate() + ', ' + t.getFullYear();
        return encodeHTML`<time datetime="${time}">${formatted}</time>`;
    }

    function replaceEmoji(text) {
        return text.replace(/:([a-z0-9+\-_]+):/ig, (match, key) => {
            let url = emojiMap[key];
            if (!url) {
                return match;
            }
            return `<img class="emoji" title="${match}" alt="${match}"
                src="${url}" width="18" height="18">`;
        });
    }

    function replaceCheckbox(html) {
        const TASK_PATTERN = /^\[([ x])\] (.*)/;
        let fragment = $('<div>').html(html);
        fragment.find('li').each(function () {
            let content = $(this).html();
            if (TASK_PATTERN.test(content)) {
                $(this)
                    .html(content.replace(TASK_PATTERN, (match, checked, remaining) => {
                        return `
                            <input class="ghh-task-checker"
                                type="checkbox"${checked === 'x' ? ' checked' : ''}
                                disabled> ${remaining}`;
                    }))
                    .addClass('ghh-task');
            }
        });

        return fragment.html();
    }

    function replacePlugins(text) {
        const BOUNTYSOURCE_PATTERN = /<\/?bountysource-plugin>/g;
        var result = text;

        // deal with Bountysource
        result = result.replace(BOUNTYSOURCE_PATTERN, '');

        return result;
    }

    function replaceLink(text) {
        return text.replace(/\b(https?:\/\/[^\s]+)/ig, `<a href="$1">$1</a>`);
    }

    // Code via underscore's _.compose
    function compose() {
        var args = arguments;
        var start = args.length - 1;
        return function() {
            var i = start;
            var result = args[start].apply(this, arguments);
            while (i--) {
                result = args[i].call(this, result);
            }
            return result;
        };
    };

    // Code via https://developers.google.com/web/updates/2015/01/ES6-Template-Strings
    // HTML Escape helper utility
    let htmlUtil = (function () {
        // Thanks to Andrea Giammarchi
        let reEscape = /[&<>'"]/g;
        let reUnescape = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34);/g;
        let oEscape = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#39;',
            '"': '&quot;'
        };
        let oUnescape = {
            '&amp;': '&',
            '&#38;': '&',
            '&lt;': '<',
            '&#60;': '<',
            '&gt;': '>',
            '&#62;': '>',
            '&apos;': "'",
            '&#39;': "'",
            '&quot;': '"',
            '&#34;': '"'
        };
        let fnEscape = function (m) {
            return oEscape[m];
        };
        let fnUnescape = function (m) {
            return oUnescape[m];
        };
        let replace = String.prototype.replace;

        return (Object.freeze || Object)({
            escape: function escape(s) {
                return replace.call(s, reEscape, fnEscape);
            },
            unescape: function unescape(s) {
                return replace.call(s, reUnescape, fnUnescape);
            }
        });
    }());

    // Tagged template function
    function encodeHTML(pieces) {
        let result = pieces[0];
        let substitutions = [].slice.call(arguments, 1);
        for (let i = 0; i < substitutions.length; ++i) {
            result += htmlUtil.escape(substitutions[i]) + pieces[i + 1];
        }

        return result;
    }

    function getCardHTML(type, raw) {
        let data;
        if (type === EXTRACT_TYPE.USER) {
            data = {
                avatar: raw.avatar_url,
                userUrl: raw.html_url,
                loginName: raw.login,
                realName: raw.name,
                location: raw.location,
                isAdmin: raw.site_admin,
                isOrg: raw.type === 'Organization',
                company: raw.company,
                followers: formatNumber(raw.followers),
                following: formatNumber(raw.following),
                repos: formatNumber(raw.public_repos),
                followersUrl: `//${GH_DOMAIN}/${raw.login}/followers`,
                followingUrl: `//${GH_DOMAIN}/${raw.login}/following`,
                reposUrl: `//${GH_DOMAIN}/${raw.login}?tab=repositories`,
                icons: {
                    location: getIcon('location', 0.875),
                    organization: getIcon('organization', 0.875)
                }
            };
        } else if (type === EXTRACT_TYPE.REPO) {
            data = {
                owner: raw.owner.login,
                ownerAvatar: raw.owner.avatar_url,
                ownerUrl: raw.owner.html_url,
                repo: raw.name,
                repoUrl: raw.html_url,
                desc: raw.description ? compose(replaceEmoji, replaceLink)(encodeHTML`${raw.description}`) : '',
                language: raw.language,
                stars: formatNumber(raw.stargazers_count),
                forks: formatNumber(raw.forks_count),
                issues: formatNumber(raw.open_issues_count),
                hasIssues: raw.has_issues,
                homepage: raw.homepage
                    ? raw.homepage.match(/^https?:\/\//) ? raw.homepage : `http://${raw.homepage}`
                    : null,
                starsUrl: `//${GH_DOMAIN}/${raw.full_name}/stargazers`,
                forksUrl: `//${GH_DOMAIN}/${raw.full_name}/network`,
                issuesUrl: `//${GH_DOMAIN}/${raw.full_name}/issues`,
                icons: {
                    repo: getIcon(raw.parent ? 'repo-forked' : 'repo', 1.5),
                    info: getIcon('info', 0.875),
                    link: getIcon('link', 0.875),
                    code: getIcon('code', 0.875)
                }
            };
            if (raw.parent) {
                data.parent = {
                    repo: raw.parent.full_name,
                    url: raw.parent.html_url
                };
            }
        } else if (type === EXTRACT_TYPE.ISSUE) {
            data = {
                title: raw.title,
                body: raw.bodyHTML,
                issueUrl: raw.html_url,
                number: raw.number,
                isPullRequest: !!raw.pull_request,
                isClosed: raw.state === 'closed',
                userUrl: raw.user.html_url,
                user: raw.user.login,
                state: raw.state,
                avatar: raw.user.avatar_url,
                createTime: formatTime(raw.created_at),
                icons: {
                    state: getIcon(raw.pull_request ? 'git-pull-request' : (raw.state === 'closed' ? 'issue-closed' : 'issue-opened'), 0.875),
                    commit: getIcon('git-commit', 0.875),
                    arrow: getIcon('arrow-right', 0.875),
                    diff: getIcon('diff', 0.875)
                }
            };
            if (raw.pull_request) {
                Object.assign(data, {
                    headRef: raw.head.ref,
                    headUser: raw.head.user.login,
                    baseRef: raw.base.ref,
                    baseUser: raw.base.user.login,
                    commits: raw.commits,
                    additions: raw.additions,
                    deletions: raw.deletions,
                    changedFiles: raw.changed_files,
                    isSingleCommit: raw.commits === 1,
                    isSingleFile: raw.changed_files === 1
                })
            }
        }

        let html = Mustache.render(CARD_TPL[type], data);
        return $(html);
    }

    function getErrorHTML(error) {
        let html = Mustache.render(CARD_TPL.error, error);
        return $(html);
    }

    // prepare token form
    let tokenForm = $(CARD_TPL.form);
    let tokenField = tokenForm.find('.ghh-token');
    tokenForm.find('.ghh-save').on('click', () => {
        let newToken = tokenField.val().trim();
        if (newToken) {
            localStorage.setItem(TOKEN_KEY, newToken);
            token = newToken;
        }
        tokenForm.detach();
        return false;
    });
    tokenForm.find('.ghh-cancel').on('click', () => {
        tokenForm.detach();
        return false;
    });
    $('body').on('click', '.token-link', () => {
        tokenForm.appendTo($('body'));
        tokenField.focus();
    });

    // prepare cache objects
    let cache = {
        user: {},
        repo: {},
        issue: {}
    };

    function extract(context) {
        isExtracting = true;

        // if on user profile page, we should not show user
        // hovercard for the said user
        let current = location.href.match(URL_USER_PATTERN);
        if (current) {
            current = current[1];
            if (GH_RESERVED_USER_NAMES.indexOf(current) !== -1
                || !GH_USER_NAME_PATTERN.test(current)) {
                current = null;
            }
        }

        let selectors = Object.keys(STRATEGIES);
        selectors.forEach(selector => {
            let strategy = STRATEGIES[selector];
            let elems = $(selector, context);
            elems.each(function () {
                let elem = $(this);
                if (getExtracted(elem) || elem.is(BLACK_LIST_SELECTOR)) {
                    // skip processed elements
                    return;
                }
                let username; // {{user}}
                let repo; // {{repo}}
                let fullRepo; // {{user}}/{{repo}}
                let issue; // {{issue}}
                let fullIssue; // {{user}}/{{repo}}#{{issue}}
                switch (strategy) {
                    case EXTRACTOR.TEXT_USER: {
                        username = trim(elem.text().replace(/[@\/]/g, ''));
                        break;
                    }
                    case EXTRACTOR.TITLE_USER: {
                        username = trim(elem.attr('title').replace(/[@\/]/g, ''));
                        break;
                    }
                    case EXTRACTOR.ALT_USER: {
                        username = trim(elem.attr('alt').replace(/[@\/]/g, ''));
                        break;
                    }
                    case EXTRACTOR.HREF_USER: {
                        username = trim(elem.attr('href').replace(/[@\/]/g, ''));
                        break;
                    }
                    case EXTRACTOR.SLUG: {
                        let slug = elem.text();
                        let match = slug.match(SLUG_PATTERN);
                        username = trim(match && match[1]);
                        repo = trim(match && match[2]);
                        issue = trim(match && match[3]);
                        if (username && repo) {
                            fullRepo = username + '/' + repo;

                            // special case for code search highlight
                            // save contents before replacing
                            let contents = elem.find('em').length
                                ? elem.contents().map(function (i) {
                                    let text = i === 0 ? (this.textContent.split('/')[1] || '') : this.textContent;
                                    // whitelisting <em>s for safety
                                    return this.nodeName.toLowerCase() === 'em'
                                        ? `<em>${text}</em>`
                                        : text;
                                }).toArray().join('')
                                : null;

                            if (issue) {
                                elem.html(slug.replace('#' + issue, encodeHTML`#<span>${issue}</span>`));
                                slug = elem.html();
                            }

                            let repoContents = contents || repo; // safe HTML or plain text
                            if (username === me || username === current) {
                                elem.html(slug.replace(fullRepo, encodeHTML`${username}/<span>` + repoContents + '</span>'));
                                markExtracted(elem.children().first(), EXTRACT_TYPE.REPO, fullRepo);
                            } else {
                                elem.html(slug.replace(fullRepo, encodeHTML`<span>${username}</span>/<span>` + repoContents + '</span>'));
                                markExtracted(elem.children().first(), EXTRACT_TYPE.USER, username);
                                markExtracted(elem.children().first().next(), EXTRACT_TYPE.REPO, fullRepo);
                            }
                            if (issue) {
                                markExtracted(elem.children().last(), EXTRACT_TYPE.ISSUE, fullRepo + '#' + issue);
                            }

                            // if not marked earlier, mark as nothing extracted
                            if (!getExtracted(elem)) {
                                markExtracted(elem);
                            }
                            elem = null;
                        }
                        break;
                    }
                    case EXTRACTOR.URL: {
                        let attr = elem.attr('href');
                        if (attr && attr.charAt(0) === '#') {
                            // ignore local anchors
                            return;
                        }
                        let href = elem.prop('href'); // absolute path via prop
                        if (href) {
                            let match = href.match(URL_USER_PATTERN);
                            username = trim(match && match[1]);
                            if (!username) {
                                match = href.match(URL_REPO_PATTERN);
                                username = trim(match && match[1]);
                                repo = trim(match && match[2]);
                            }
                            if (!username) {
                                match = href.match(URL_ISSUE_PATTERN);
                                username = trim(match && match[1]);
                                repo = trim(match && match[2]);
                                issue = trim(match && match[3]);
                            }
                            if (username) {
                                if (GH_RESERVED_USER_NAMES.indexOf(username) !== -1
                                    || !GH_USER_NAME_PATTERN.test(username)) {
                                    username = null;
                                    repo = null;
                                    issue = null;
                                }
                            }
                            if (repo) {
                                fullRepo = `${username}/${repo}`;
                                if (GH_RESERVED_REPO_NAMES.indexOf(repo) !== -1
                                    || !GH_REPO_NAME_PATTERN.test(repo)) {
                                    fullRepo = null;
                                    username = null;
                                    issue = null;
                                }
                            }
                            if (issue) {
                                fullIssue = `${username}/${repo}#${issue}`;
                            }
                            // skip hovercard on myself or current profile page owner
                            if ((username === me || username === current) && !repo) {
                                username = null;
                            }
                        }
                        break;
                    }
                    case EXTRACTOR.NEXT_TEXT_REPO: {
                        fullRepo = getFullRepoFromAncestorLink(elem);
                        repo = fullRepo.split('/')[1];
                        let textNode = elem[0].nextSibling;
                        if (fullRepo && textNode) {
                            textNode.parentNode.removeChild(textNode);
                            elem.after(` <span>${repo}</span>`);
                            markExtracted(elem);
                            markExtracted(elem.next(), EXTRACT_TYPE.REPO, fullRepo);
                        }
                        elem = null;
                        break;
                    }
                    case EXTRACTOR.ANCESTOR_URL_REPO: {
                        fullRepo = getFullRepoFromAncestorLink(elem);
                        break;
                    }
                    default:
                        break;
                }

                // elem === null means already marked in extractors
                if (!elem) {
                    return;
                }
                if (fullIssue) {
                    markExtracted(elem, EXTRACT_TYPE.ISSUE, fullIssue);
                } else if (fullRepo) {
                    markExtracted(elem, EXTRACT_TYPE.REPO, fullRepo);
                } else if (username && username !== me && username !== current) {
                    markExtracted(elem, EXTRACT_TYPE.USER, username);
                }
                if (!username && !fullRepo && !fullIssue) {
                    markExtracted(elem);
                }
            });
        });

        setTimeout(() => {
            isExtracting = false;
        }, 0);

        let tipSelector = Object.keys(EXTRACT_TYPE)
            .map(key => EXTRACT_TYPE[key])
            .map(getTypeClass)
            .map(className => `.${className}`)
            .join(',');

        let tipped = $(tipSelector);
        tipped.tooltipster({
            updateAnimation: false,
            contentAsHTML: true,
            debug: false,
            delay: cardOptions.delay,
            // trigger: 'click',
            functionBefore: (me, event) => {
                let elem = $(event.origin);
                elem.tooltipster('content', $('<span class="loading"></span>'));
                let type = elem.data(TYPE_KEY);
                let value = elem.data(VALUE_KEY);

                let raw = cache[type][value];
                if (raw) {
                    elem.tooltipster('content', getCardHTML(type, raw));
                } else {
                    let apiPath;
                    switch (type) {
                        case EXTRACT_TYPE.USER:
                            apiPath = `users/${value}`;
                            break;
                        case EXTRACT_TYPE.REPO:
                            apiPath = `repos/${value}`;
                            break;
                        case EXTRACT_TYPE.ISSUE: {
                            let values = value.split('#');
                            let fullRepo = values[0];
                            let issue = values[1];
                            apiPath = `repos/${fullRepo}/issues/${issue}`;
                            break;
                        }
                    }
                    let baseOptions = {
                        url: API_PREFIX + apiPath,
                        dataType: 'json'
                    };

                    let isRetry = false;
                    let handleError = function (xhr) {
                        let status = xhr.status;
                        let title = '';
                        let message = '';
                        let needToken = false;

                        switch (status) {
                            case 0:
                                if (isRetry) {
                                    title = 'Connection error';
                                    message = 'Please try again later.';
                                } else {
                                    // next request should be retry
                                    isRetry = true;
                                    request();
                                    return;
                                }
                                break;
                            case 401:
                                title = 'Invalid token';
                                message = encodeHTML`<a href="${CREATE_TOKEN_PATH}" class="token-link" target="_blank">Create a new access token</a>, <a href="#" class="token-link">paste it back here</a> and try again.`;
                                needToken = true;
                                break;
                            case 403:
                                if (xhr.getAllResponseHeaders().indexOf('X-RateLimit-Remaining: 0') !== -1) {
                                    title = 'API limit exceeded';
                                    if (!localStorage.getItem(TOKEN_KEY)) {
                                        message = encodeHTML`API rate limit exceeded for current IP. <a href="${CREATE_TOKEN_PATH}" class="token-link" target="_blank">Create a new access token</a> and <a href="#" class="token-link">paste it back here</a> to get a higher rate limit.`;
                                    }
                                } else {
                                    let response = xhr.responseJSON;
                                    if (type === EXTRACT_TYPE.REPO && response.block && response.block.reason === 'dmca') {
                                        title = 'Access blocked';
                                        message = 'Repository unavailable due to DMCA takedown.';
                                    } else {
                                        title = 'Forbidden';
                                        message = encodeHTML`You are not allowed to access GitHub API. <a href="${CREATE_TOKEN_PATH}" class="token-link" target="_blank">Create a new access token</a>, <a href="#" class="token-link">paste it back here</a> and try again.`;
                                    }
                                }
                                needToken = true;
                                break;
                            case 404:
                                title = 'Not found';
                                if (type === EXTRACT_TYPE.REPO || type === EXTRACT_TYPE.ISSUE) {
                                    message = encodeHTML`The repository doesn\'t exist or is private. <a href="${CREATE_TOKEN_PATH}" class="token-link" target="_blank">Create a new access token</a>, <a href="#" class="token-link">paste it back here</a> and try again.`;
                                    needToken = true;
                                } else if (type === EXTRACT_TYPE.USER) {
                                    message = `The user doesn't exist.`;
                                }
                                break;
                            default:
                                title = 'Error';
                                let response = xhr.responseJSON;
                                if (response) {
                                    message = encodeHTML`${response.message}` || '';
                                }
                                break;
                        }

                        let error = {
                            title: title,
                            message: message,
                            needToken: needToken,
                            icons: {
                                alert: getIcon('alert')
                            }
                        };
                        elem.tooltipster('content', getErrorHTML(error));
                    }

                    let request = function () {
                        let authOptions = {};
                        if (token && !isRetry) {
                            authOptions = {
                                headers: {
                                    Authorization: `token ${token}`
                                }
                            };
                        }

                        let requestOptions = Object.assign({}, baseOptions, authOptions);

                        $.ajax(requestOptions)
                            .done(raw => {
                                cache[type][value] = raw;

                                // further requests if necessary
                                switch(type) {
                                    case EXTRACT_TYPE.ISSUE: {
                                        let todo = 0;
                                        if (raw.body) {
                                            todo++;
                                            let options = {
                                                url: API_PREFIX + 'markdown',
                                                method: 'POST',
                                                contentType: 'application/json',
                                                dataType: 'text',
                                                data: JSON.stringify({
                                                    text: raw.body,
                                                    mode: 'gfm',
                                                    context: value.split('#')[0]
                                                })
                                            }
                                            $.ajax(Object.assign({}, requestOptions, options))
                                                .done(html => {
                                                    raw.bodyHTML = html;
                                                    if (!--todo) {
                                                        elem.tooltipster('content', getCardHTML(type, raw));
                                                    }
                                                })
                                                .fail(handleError);
                                        }
                                        if (raw.pull_request) {
                                            todo++;
                                            let prPath = apiPath.replace(/\/issues\/(\d+)$/, '/pulls/$1');
                                            let options = {
                                                url: API_PREFIX + prPath,
                                                dataType: 'json'
                                            };
                                            $.ajax(Object.assign({}, requestOptions, options))
                                                .done(pull => {
                                                    let extra = {
                                                        commits: pull.commits,
                                                        additions: pull.additions,
                                                        deletions: pull.deletions,
                                                        changed_files: pull.changed_files,
                                                        head: pull.head,
                                                        base: pull.base
                                                    };
                                                    if (pull.merged) {
                                                        extra.state = 'merged';
                                                    }
                                                    Object.assign(raw, extra);
                                                    Object.assign(cache[type][value], extra);
                                                    if (!--todo) {
                                                        elem.tooltipster('content', getCardHTML(type, raw));
                                                    }
                                                })
                                                .fail(handleError);
                                        }

                                        // wait for async handler
                                        if (todo) {
                                            return;
                                        }
                                    }
                                }

                                elem.tooltipster('content', getCardHTML(type, raw));
                            })
                            .fail(handleError);
                    };
                    request();
                }
            },
            interactive: true
        });

        if ('webkitTransform' in document.body.style) {
            // why? see https://github.com/iamceege/tooltipster/issues/491
            // use box-shadow instead to prevent weirder problem...
            tipped.css('box-shadow', '0 0 transparent');
        }

        // Listen for future mutations but not ones happens
        // in current extraction process
        setTimeout(() => {
            isExtracting = false;
        }, 0);
    }

    let emojiMap = {"100":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4af.png?v5","1234":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f522.png?v5","+1":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44d.png?v5","-1":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44e.png?v5","8ball":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b1.png?v5","a":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f170.png?v5","ab":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f18e.png?v5","abc":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f524.png?v5","abcd":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f521.png?v5","accept":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f251.png?v5","aerial_tramway":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a1.png?v5","airplane":"https://assets-cdn.github.com/images/icons/emoji/unicode/2708.png?v5","alarm_clock":"https://assets-cdn.github.com/images/icons/emoji/unicode/23f0.png?v5","alien":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f47d.png?v5","ambulance":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f691.png?v5","anchor":"https://assets-cdn.github.com/images/icons/emoji/unicode/2693.png?v5","angel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f47c.png?v5","anger":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a2.png?v5","angry":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f620.png?v5","anguished":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f627.png?v5","ant":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41c.png?v5","apple":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f34e.png?v5","aquarius":"https://assets-cdn.github.com/images/icons/emoji/unicode/2652.png?v5","aries":"https://assets-cdn.github.com/images/icons/emoji/unicode/2648.png?v5","arrow_backward":"https://assets-cdn.github.com/images/icons/emoji/unicode/25c0.png?v5","arrow_double_down":"https://assets-cdn.github.com/images/icons/emoji/unicode/23ec.png?v5","arrow_double_up":"https://assets-cdn.github.com/images/icons/emoji/unicode/23eb.png?v5","arrow_down":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b07.png?v5","arrow_down_small":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f53d.png?v5","arrow_forward":"https://assets-cdn.github.com/images/icons/emoji/unicode/25b6.png?v5","arrow_heading_down":"https://assets-cdn.github.com/images/icons/emoji/unicode/2935.png?v5","arrow_heading_up":"https://assets-cdn.github.com/images/icons/emoji/unicode/2934.png?v5","arrow_left":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b05.png?v5","arrow_lower_left":"https://assets-cdn.github.com/images/icons/emoji/unicode/2199.png?v5","arrow_lower_right":"https://assets-cdn.github.com/images/icons/emoji/unicode/2198.png?v5","arrow_right":"https://assets-cdn.github.com/images/icons/emoji/unicode/27a1.png?v5","arrow_right_hook":"https://assets-cdn.github.com/images/icons/emoji/unicode/21aa.png?v5","arrow_up":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b06.png?v5","arrow_up_down":"https://assets-cdn.github.com/images/icons/emoji/unicode/2195.png?v5","arrow_up_small":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f53c.png?v5","arrow_upper_left":"https://assets-cdn.github.com/images/icons/emoji/unicode/2196.png?v5","arrow_upper_right":"https://assets-cdn.github.com/images/icons/emoji/unicode/2197.png?v5","arrows_clockwise":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f503.png?v5","arrows_counterclockwise":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f504.png?v5","art":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a8.png?v5","articulated_lorry":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f69b.png?v5","astonished":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f632.png?v5","athletic_shoe":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45f.png?v5","atm":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e7.png?v5","b":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f171.png?v5","baby":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f476.png?v5","baby_bottle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f37c.png?v5","baby_chick":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f424.png?v5","baby_symbol":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6bc.png?v5","back":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f519.png?v5","baggage_claim":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6c4.png?v5","balloon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f388.png?v5","ballot_box_with_check":"https://assets-cdn.github.com/images/icons/emoji/unicode/2611.png?v5","bamboo":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f38d.png?v5","banana":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f34c.png?v5","bangbang":"https://assets-cdn.github.com/images/icons/emoji/unicode/203c.png?v5","bank":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e6.png?v5","bar_chart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ca.png?v5","barber":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f488.png?v5","baseball":"https://assets-cdn.github.com/images/icons/emoji/unicode/26be.png?v5","basketball":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c0.png?v5","bath":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6c0.png?v5","bathtub":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6c1.png?v5","battery":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f50b.png?v5","bear":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f43b.png?v5","bee":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41d.png?v5","beer":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f37a.png?v5","beers":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f37b.png?v5","beetle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41e.png?v5","beginner":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f530.png?v5","bell":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f514.png?v5","bento":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f371.png?v5","bicyclist":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b4.png?v5","bike":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b2.png?v5","bikini":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f459.png?v5","bird":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f426.png?v5","birthday":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f382.png?v5","black_circle":"https://assets-cdn.github.com/images/icons/emoji/unicode/26ab.png?v5","black_joker":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f0cf.png?v5","black_large_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b1b.png?v5","black_medium_small_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/25fe.png?v5","black_medium_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/25fc.png?v5","black_nib":"https://assets-cdn.github.com/images/icons/emoji/unicode/2712.png?v5","black_small_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/25aa.png?v5","black_square_button":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f532.png?v5","blossom":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f33c.png?v5","blowfish":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f421.png?v5","blue_book":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d8.png?v5","blue_car":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f699.png?v5","blue_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f499.png?v5","blush":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f60a.png?v5","boar":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f417.png?v5","boat":"https://assets-cdn.github.com/images/icons/emoji/unicode/26f5.png?v5","bomb":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a3.png?v5","book":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d6.png?v5","bookmark":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f516.png?v5","bookmark_tabs":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d1.png?v5","books":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4da.png?v5","boom":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a5.png?v5","boot":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f462.png?v5","bouquet":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f490.png?v5","bow":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f647.png?v5","bowling":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b3.png?v5","bowtie":"https://assets-cdn.github.com/images/icons/emoji/bowtie.png?v5","boy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f466.png?v5","bread":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f35e.png?v5","bride_with_veil":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f470.png?v5","bridge_at_night":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f309.png?v5","briefcase":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4bc.png?v5","broken_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f494.png?v5","bug":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41b.png?v5","bulb":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a1.png?v5","bullettrain_front":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f685.png?v5","bullettrain_side":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f684.png?v5","bus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f68c.png?v5","busstop":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f68f.png?v5","bust_in_silhouette":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f464.png?v5","busts_in_silhouette":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f465.png?v5","cactus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f335.png?v5","cake":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f370.png?v5","calendar":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c6.png?v5","calling":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f2.png?v5","camel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42b.png?v5","camera":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f7.png?v5","cancer":"https://assets-cdn.github.com/images/icons/emoji/unicode/264b.png?v5","candy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f36c.png?v5","capital_abcd":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f520.png?v5","capricorn":"https://assets-cdn.github.com/images/icons/emoji/unicode/2651.png?v5","car":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f697.png?v5","card_index":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c7.png?v5","carousel_horse":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a0.png?v5","cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f431.png?v5","cat2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f408.png?v5","cd":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4bf.png?v5","chart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b9.png?v5","chart_with_downwards_trend":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c9.png?v5","chart_with_upwards_trend":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c8.png?v5","checkered_flag":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c1.png?v5","cherries":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f352.png?v5","cherry_blossom":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f338.png?v5","chestnut":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f330.png?v5","chicken":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f414.png?v5","children_crossing":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b8.png?v5","chocolate_bar":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f36b.png?v5","christmas_tree":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f384.png?v5","church":"https://assets-cdn.github.com/images/icons/emoji/unicode/26ea.png?v5","cinema":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a6.png?v5","circus_tent":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3aa.png?v5","city_sunrise":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f307.png?v5","city_sunset":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f306.png?v5","cl":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f191.png?v5","clap":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44f.png?v5","clapper":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ac.png?v5","clipboard":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4cb.png?v5","clock1":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f550.png?v5","clock10":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f559.png?v5","clock1030":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f565.png?v5","clock11":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f55a.png?v5","clock1130":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f566.png?v5","clock12":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f55b.png?v5","clock1230":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f567.png?v5","clock130":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f55c.png?v5","clock2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f551.png?v5","clock230":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f55d.png?v5","clock3":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f552.png?v5","clock330":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f55e.png?v5","clock4":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f553.png?v5","clock430":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f55f.png?v5","clock5":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f554.png?v5","clock530":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f560.png?v5","clock6":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f555.png?v5","clock630":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f561.png?v5","clock7":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f556.png?v5","clock730":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f562.png?v5","clock8":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f557.png?v5","clock830":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f563.png?v5","clock9":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f558.png?v5","clock930":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f564.png?v5","closed_book":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d5.png?v5","closed_lock_with_key":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f510.png?v5","closed_umbrella":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f302.png?v5","cloud":"https://assets-cdn.github.com/images/icons/emoji/unicode/2601.png?v5","clubs":"https://assets-cdn.github.com/images/icons/emoji/unicode/2663.png?v5","cn":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1e8-1f1f3.png?v5","cocktail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f378.png?v5","coffee":"https://assets-cdn.github.com/images/icons/emoji/unicode/2615.png?v5","cold_sweat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f630.png?v5","collision":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a5.png?v5","computer":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4bb.png?v5","confetti_ball":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f38a.png?v5","confounded":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f616.png?v5","confused":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f615.png?v5","congratulations":"https://assets-cdn.github.com/images/icons/emoji/unicode/3297.png?v5","construction":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a7.png?v5","construction_worker":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f477.png?v5","convenience_store":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ea.png?v5","cookie":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f36a.png?v5","cool":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f192.png?v5","cop":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f46e.png?v5","copyright":"https://assets-cdn.github.com/images/icons/emoji/unicode/00a9.png?v5","corn":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f33d.png?v5","couple":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f46b.png?v5","couple_with_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f491.png?v5","couplekiss":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f48f.png?v5","cow":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42e.png?v5","cow2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f404.png?v5","credit_card":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b3.png?v5","crescent_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f319.png?v5","crocodile":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f40a.png?v5","crossed_flags":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f38c.png?v5","crown":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f451.png?v5","cry":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f622.png?v5","crying_cat_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f63f.png?v5","crystal_ball":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52e.png?v5","cupid":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f498.png?v5","curly_loop":"https://assets-cdn.github.com/images/icons/emoji/unicode/27b0.png?v5","currency_exchange":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b1.png?v5","curry":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f35b.png?v5","custard":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f36e.png?v5","customs":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6c3.png?v5","cyclone":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f300.png?v5","dancer":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f483.png?v5","dancers":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f46f.png?v5","dango":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f361.png?v5","dart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3af.png?v5","dash":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a8.png?v5","date":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c5.png?v5","de":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1e9-1f1ea.png?v5","deciduous_tree":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f333.png?v5","department_store":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ec.png?v5","diamond_shape_with_a_dot_inside":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a0.png?v5","diamonds":"https://assets-cdn.github.com/images/icons/emoji/unicode/2666.png?v5","disappointed":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f61e.png?v5","disappointed_relieved":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f625.png?v5","dizzy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ab.png?v5","dizzy_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f635.png?v5","do_not_litter":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6af.png?v5","dog":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f436.png?v5","dog2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f415.png?v5","dollar":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b5.png?v5","dolls":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f38e.png?v5","dolphin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42c.png?v5","door":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6aa.png?v5","doughnut":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f369.png?v5","dragon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f409.png?v5","dragon_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f432.png?v5","dress":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f457.png?v5","dromedary_camel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42a.png?v5","droplet":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a7.png?v5","dvd":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c0.png?v5","e-mail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e7.png?v5","ear":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f442.png?v5","ear_of_rice":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f33e.png?v5","earth_africa":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f30d.png?v5","earth_americas":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f30e.png?v5","earth_asia":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f30f.png?v5","egg":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f373.png?v5","eggplant":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f346.png?v5","eight":"https://assets-cdn.github.com/images/icons/emoji/unicode/0038-20e3.png?v5","eight_pointed_black_star":"https://assets-cdn.github.com/images/icons/emoji/unicode/2734.png?v5","eight_spoked_asterisk":"https://assets-cdn.github.com/images/icons/emoji/unicode/2733.png?v5","electric_plug":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f50c.png?v5","elephant":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f418.png?v5","email":"https://assets-cdn.github.com/images/icons/emoji/unicode/2709.png?v5","end":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f51a.png?v5","envelope":"https://assets-cdn.github.com/images/icons/emoji/unicode/2709.png?v5","envelope_with_arrow":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e9.png?v5","es":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1ea-1f1f8.png?v5","euro":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b6.png?v5","european_castle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3f0.png?v5","european_post_office":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e4.png?v5","evergreen_tree":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f332.png?v5","exclamation":"https://assets-cdn.github.com/images/icons/emoji/unicode/2757.png?v5","expressionless":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f611.png?v5","eyeglasses":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f453.png?v5","eyes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f440.png?v5","facepunch":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44a.png?v5","factory":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ed.png?v5","fallen_leaf":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f342.png?v5","family":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f46a.png?v5","fast_forward":"https://assets-cdn.github.com/images/icons/emoji/unicode/23e9.png?v5","fax":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e0.png?v5","fearful":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f628.png?v5","feelsgood":"https://assets-cdn.github.com/images/icons/emoji/feelsgood.png?v5","feet":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f43e.png?v5","ferris_wheel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a1.png?v5","file_folder":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c1.png?v5","finnadie":"https://assets-cdn.github.com/images/icons/emoji/finnadie.png?v5","fire":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f525.png?v5","fire_engine":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f692.png?v5","fireworks":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f386.png?v5","first_quarter_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f313.png?v5","first_quarter_moon_with_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f31b.png?v5","fish":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41f.png?v5","fish_cake":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f365.png?v5","fishing_pole_and_fish":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a3.png?v5","fist":"https://assets-cdn.github.com/images/icons/emoji/unicode/270a.png?v5","five":"https://assets-cdn.github.com/images/icons/emoji/unicode/0035-20e3.png?v5","flags":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f38f.png?v5","flashlight":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f526.png?v5","flipper":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42c.png?v5","floppy_disk":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4be.png?v5","flower_playing_cards":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b4.png?v5","flushed":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f633.png?v5","foggy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f301.png?v5","football":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c8.png?v5","footprints":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f463.png?v5","fork_and_knife":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f374.png?v5","fountain":"https://assets-cdn.github.com/images/icons/emoji/unicode/26f2.png?v5","four":"https://assets-cdn.github.com/images/icons/emoji/unicode/0034-20e3.png?v5","four_leaf_clover":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f340.png?v5","fr":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1eb-1f1f7.png?v5","free":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f193.png?v5","fried_shrimp":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f364.png?v5","fries":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f35f.png?v5","frog":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f438.png?v5","frowning":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f626.png?v5","fu":"https://assets-cdn.github.com/images/icons/emoji/fu.png?v5","fuelpump":"https://assets-cdn.github.com/images/icons/emoji/unicode/26fd.png?v5","full_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f315.png?v5","full_moon_with_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f31d.png?v5","game_die":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b2.png?v5","gb":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1ec-1f1e7.png?v5","gem":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f48e.png?v5","gemini":"https://assets-cdn.github.com/images/icons/emoji/unicode/264a.png?v5","ghost":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f47b.png?v5","gift":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f381.png?v5","gift_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f49d.png?v5","girl":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f467.png?v5","globe_with_meridians":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f310.png?v5","goat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f410.png?v5","goberserk":"https://assets-cdn.github.com/images/icons/emoji/goberserk.png?v5","godmode":"https://assets-cdn.github.com/images/icons/emoji/godmode.png?v5","golf":"https://assets-cdn.github.com/images/icons/emoji/unicode/26f3.png?v5","grapes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f347.png?v5","green_apple":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f34f.png?v5","green_book":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d7.png?v5","green_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f49a.png?v5","grey_exclamation":"https://assets-cdn.github.com/images/icons/emoji/unicode/2755.png?v5","grey_question":"https://assets-cdn.github.com/images/icons/emoji/unicode/2754.png?v5","grimacing":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f62c.png?v5","grin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f601.png?v5","grinning":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f600.png?v5","guardsman":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f482.png?v5","guitar":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b8.png?v5","gun":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52b.png?v5","haircut":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f487.png?v5","hamburger":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f354.png?v5","hammer":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f528.png?v5","hamster":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f439.png?v5","hand":"https://assets-cdn.github.com/images/icons/emoji/unicode/270b.png?v5","handbag":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45c.png?v5","hankey":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a9.png?v5","hash":"https://assets-cdn.github.com/images/icons/emoji/unicode/0023-20e3.png?v5","hatched_chick":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f425.png?v5","hatching_chick":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f423.png?v5","headphones":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a7.png?v5","hear_no_evil":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f649.png?v5","heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/2764.png?v5","heart_decoration":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f49f.png?v5","heart_eyes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f60d.png?v5","heart_eyes_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f63b.png?v5","heartbeat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f493.png?v5","heartpulse":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f497.png?v5","hearts":"https://assets-cdn.github.com/images/icons/emoji/unicode/2665.png?v5","heavy_check_mark":"https://assets-cdn.github.com/images/icons/emoji/unicode/2714.png?v5","heavy_division_sign":"https://assets-cdn.github.com/images/icons/emoji/unicode/2797.png?v5","heavy_dollar_sign":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b2.png?v5","heavy_exclamation_mark":"https://assets-cdn.github.com/images/icons/emoji/unicode/2757.png?v5","heavy_minus_sign":"https://assets-cdn.github.com/images/icons/emoji/unicode/2796.png?v5","heavy_multiplication_x":"https://assets-cdn.github.com/images/icons/emoji/unicode/2716.png?v5","heavy_plus_sign":"https://assets-cdn.github.com/images/icons/emoji/unicode/2795.png?v5","helicopter":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f681.png?v5","herb":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f33f.png?v5","hibiscus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f33a.png?v5","high_brightness":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f506.png?v5","high_heel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f460.png?v5","hocho":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52a.png?v5","honey_pot":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f36f.png?v5","honeybee":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41d.png?v5","horse":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f434.png?v5","horse_racing":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c7.png?v5","hospital":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e5.png?v5","hotel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e8.png?v5","hotsprings":"https://assets-cdn.github.com/images/icons/emoji/unicode/2668.png?v5","hourglass":"https://assets-cdn.github.com/images/icons/emoji/unicode/231b.png?v5","hourglass_flowing_sand":"https://assets-cdn.github.com/images/icons/emoji/unicode/23f3.png?v5","house":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e0.png?v5","house_with_garden":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e1.png?v5","hurtrealbad":"https://assets-cdn.github.com/images/icons/emoji/hurtrealbad.png?v5","hushed":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f62f.png?v5","ice_cream":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f368.png?v5","icecream":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f366.png?v5","id":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f194.png?v5","ideograph_advantage":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f250.png?v5","imp":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f47f.png?v5","inbox_tray":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e5.png?v5","incoming_envelope":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e8.png?v5","information_desk_person":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f481.png?v5","information_source":"https://assets-cdn.github.com/images/icons/emoji/unicode/2139.png?v5","innocent":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f607.png?v5","interrobang":"https://assets-cdn.github.com/images/icons/emoji/unicode/2049.png?v5","iphone":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f1.png?v5","it":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1ee-1f1f9.png?v5","izakaya_lantern":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ee.png?v5","jack_o_lantern":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f383.png?v5","japan":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f5fe.png?v5","japanese_castle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ef.png?v5","japanese_goblin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f47a.png?v5","japanese_ogre":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f479.png?v5","jeans":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f456.png?v5","joy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f602.png?v5","joy_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f639.png?v5","jp":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1ef-1f1f5.png?v5","key":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f511.png?v5","keycap_ten":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f51f.png?v5","kimono":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f458.png?v5","kiss":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f48b.png?v5","kissing":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f617.png?v5","kissing_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f63d.png?v5","kissing_closed_eyes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f61a.png?v5","kissing_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f618.png?v5","kissing_smiling_eyes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f619.png?v5","knife":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52a.png?v5","koala":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f428.png?v5","koko":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f201.png?v5","kr":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1f0-1f1f7.png?v5","lantern":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ee.png?v5","large_blue_circle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f535.png?v5","large_blue_diamond":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f537.png?v5","large_orange_diamond":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f536.png?v5","last_quarter_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f317.png?v5","last_quarter_moon_with_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f31c.png?v5","laughing":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f606.png?v5","leaves":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f343.png?v5","ledger":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d2.png?v5","left_luggage":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6c5.png?v5","left_right_arrow":"https://assets-cdn.github.com/images/icons/emoji/unicode/2194.png?v5","leftwards_arrow_with_hook":"https://assets-cdn.github.com/images/icons/emoji/unicode/21a9.png?v5","lemon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f34b.png?v5","leo":"https://assets-cdn.github.com/images/icons/emoji/unicode/264c.png?v5","leopard":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f406.png?v5","libra":"https://assets-cdn.github.com/images/icons/emoji/unicode/264e.png?v5","light_rail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f688.png?v5","link":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f517.png?v5","lips":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f444.png?v5","lipstick":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f484.png?v5","lock":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f512.png?v5","lock_with_ink_pen":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f50f.png?v5","lollipop":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f36d.png?v5","loop":"https://assets-cdn.github.com/images/icons/emoji/unicode/27bf.png?v5","loud_sound":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f50a.png?v5","loudspeaker":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e2.png?v5","love_hotel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e9.png?v5","love_letter":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f48c.png?v5","low_brightness":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f505.png?v5","m":"https://assets-cdn.github.com/images/icons/emoji/unicode/24c2.png?v5","mag":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f50d.png?v5","mag_right":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f50e.png?v5","mahjong":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f004.png?v5","mailbox":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4eb.png?v5","mailbox_closed":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ea.png?v5","mailbox_with_mail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ec.png?v5","mailbox_with_no_mail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ed.png?v5","man":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f468.png?v5","man_with_gua_pi_mao":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f472.png?v5","man_with_turban":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f473.png?v5","mans_shoe":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45e.png?v5","maple_leaf":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f341.png?v5","mask":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f637.png?v5","massage":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f486.png?v5","meat_on_bone":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f356.png?v5","mega":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e3.png?v5","melon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f348.png?v5","memo":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4dd.png?v5","mens":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b9.png?v5","metal":"https://assets-cdn.github.com/images/icons/emoji/metal.png?v5","metro":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f687.png?v5","microphone":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a4.png?v5","microscope":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52c.png?v5","milky_way":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f30c.png?v5","minibus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f690.png?v5","minidisc":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4bd.png?v5","mobile_phone_off":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f4.png?v5","money_with_wings":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b8.png?v5","moneybag":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b0.png?v5","monkey":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f412.png?v5","monkey_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f435.png?v5","monorail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f69d.png?v5","moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f314.png?v5","mortar_board":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f393.png?v5","mount_fuji":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f5fb.png?v5","mountain_bicyclist":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b5.png?v5","mountain_cableway":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a0.png?v5","mountain_railway":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f69e.png?v5","mouse":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42d.png?v5","mouse2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f401.png?v5","movie_camera":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a5.png?v5","moyai":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f5ff.png?v5","muscle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4aa.png?v5","mushroom":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f344.png?v5","musical_keyboard":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b9.png?v5","musical_note":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b5.png?v5","musical_score":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3bc.png?v5","mute":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f507.png?v5","nail_care":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f485.png?v5","name_badge":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4db.png?v5","neckbeard":"https://assets-cdn.github.com/images/icons/emoji/neckbeard.png?v5","necktie":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f454.png?v5","negative_squared_cross_mark":"https://assets-cdn.github.com/images/icons/emoji/unicode/274e.png?v5","neutral_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f610.png?v5","new":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f195.png?v5","new_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f311.png?v5","new_moon_with_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f31a.png?v5","newspaper":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f0.png?v5","ng":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f196.png?v5","night_with_stars":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f303.png?v5","nine":"https://assets-cdn.github.com/images/icons/emoji/unicode/0039-20e3.png?v5","no_bell":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f515.png?v5","no_bicycles":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b3.png?v5","no_entry":"https://assets-cdn.github.com/images/icons/emoji/unicode/26d4.png?v5","no_entry_sign":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6ab.png?v5","no_good":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f645.png?v5","no_mobile_phones":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f5.png?v5","no_mouth":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f636.png?v5","no_pedestrians":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b7.png?v5","no_smoking":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6ad.png?v5","non-potable_water":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b1.png?v5","nose":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f443.png?v5","notebook":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d3.png?v5","notebook_with_decorative_cover":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d4.png?v5","notes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b6.png?v5","nut_and_bolt":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f529.png?v5","o":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b55.png?v5","o2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f17e.png?v5","ocean":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f30a.png?v5","octocat":"https://assets-cdn.github.com/images/icons/emoji/octocat.png?v5","octopus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f419.png?v5","oden":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f362.png?v5","office":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e2.png?v5","ok":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f197.png?v5","ok_hand":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44c.png?v5","ok_woman":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f646.png?v5","older_man":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f474.png?v5","older_woman":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f475.png?v5","on":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f51b.png?v5","oncoming_automobile":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f698.png?v5","oncoming_bus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f68d.png?v5","oncoming_police_car":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f694.png?v5","oncoming_taxi":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f696.png?v5","one":"https://assets-cdn.github.com/images/icons/emoji/unicode/0031-20e3.png?v5","open_book":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d6.png?v5","open_file_folder":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c2.png?v5","open_hands":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f450.png?v5","open_mouth":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f62e.png?v5","ophiuchus":"https://assets-cdn.github.com/images/icons/emoji/unicode/26ce.png?v5","orange_book":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d9.png?v5","outbox_tray":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e4.png?v5","ox":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f402.png?v5","package":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e6.png?v5","page_facing_up":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c4.png?v5","page_with_curl":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4c3.png?v5","pager":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4df.png?v5","palm_tree":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f334.png?v5","panda_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f43c.png?v5","paperclip":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ce.png?v5","parking":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f17f.png?v5","part_alternation_mark":"https://assets-cdn.github.com/images/icons/emoji/unicode/303d.png?v5","partly_sunny":"https://assets-cdn.github.com/images/icons/emoji/unicode/26c5.png?v5","passport_control":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6c2.png?v5","paw_prints":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f43e.png?v5","peach":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f351.png?v5","pear":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f350.png?v5","pencil":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4dd.png?v5","pencil2":"https://assets-cdn.github.com/images/icons/emoji/unicode/270f.png?v5","penguin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f427.png?v5","pensive":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f614.png?v5","performing_arts":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ad.png?v5","persevere":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f623.png?v5","person_frowning":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f64d.png?v5","person_with_blond_hair":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f471.png?v5","person_with_pouting_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f64e.png?v5","phone":"https://assets-cdn.github.com/images/icons/emoji/unicode/260e.png?v5","pig":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f437.png?v5","pig2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f416.png?v5","pig_nose":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f43d.png?v5","pill":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f48a.png?v5","pineapple":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f34d.png?v5","pisces":"https://assets-cdn.github.com/images/icons/emoji/unicode/2653.png?v5","pizza":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f355.png?v5","point_down":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f447.png?v5","point_left":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f448.png?v5","point_right":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f449.png?v5","point_up":"https://assets-cdn.github.com/images/icons/emoji/unicode/261d.png?v5","point_up_2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f446.png?v5","police_car":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f693.png?v5","poodle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f429.png?v5","poop":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a9.png?v5","post_office":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3e3.png?v5","postal_horn":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ef.png?v5","postbox":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ee.png?v5","potable_water":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b0.png?v5","pouch":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45d.png?v5","poultry_leg":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f357.png?v5","pound":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b7.png?v5","pouting_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f63e.png?v5","pray":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f64f.png?v5","princess":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f478.png?v5","punch":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44a.png?v5","purple_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f49c.png?v5","purse":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45b.png?v5","pushpin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4cc.png?v5","put_litter_in_its_place":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6ae.png?v5","question":"https://assets-cdn.github.com/images/icons/emoji/unicode/2753.png?v5","rabbit":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f430.png?v5","rabbit2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f407.png?v5","racehorse":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f40e.png?v5","radio":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4fb.png?v5","radio_button":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f518.png?v5","rage":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f621.png?v5","rage1":"https://assets-cdn.github.com/images/icons/emoji/rage1.png?v5","rage2":"https://assets-cdn.github.com/images/icons/emoji/rage2.png?v5","rage3":"https://assets-cdn.github.com/images/icons/emoji/rage3.png?v5","rage4":"https://assets-cdn.github.com/images/icons/emoji/rage4.png?v5","railway_car":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f683.png?v5","rainbow":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f308.png?v5","raised_hand":"https://assets-cdn.github.com/images/icons/emoji/unicode/270b.png?v5","raised_hands":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f64c.png?v5","raising_hand":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f64b.png?v5","ram":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f40f.png?v5","ramen":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f35c.png?v5","rat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f400.png?v5","recycle":"https://assets-cdn.github.com/images/icons/emoji/unicode/267b.png?v5","red_car":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f697.png?v5","red_circle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f534.png?v5","registered":"https://assets-cdn.github.com/images/icons/emoji/unicode/00ae.png?v5","relaxed":"https://assets-cdn.github.com/images/icons/emoji/unicode/263a.png?v5","relieved":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f60c.png?v5","repeat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f501.png?v5","repeat_one":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f502.png?v5","restroom":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6bb.png?v5","revolving_hearts":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f49e.png?v5","rewind":"https://assets-cdn.github.com/images/icons/emoji/unicode/23ea.png?v5","ribbon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f380.png?v5","rice":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f35a.png?v5","rice_ball":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f359.png?v5","rice_cracker":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f358.png?v5","rice_scene":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f391.png?v5","ring":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f48d.png?v5","rocket":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f680.png?v5","roller_coaster":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a2.png?v5","rooster":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f413.png?v5","rose":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f339.png?v5","rotating_light":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a8.png?v5","round_pushpin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4cd.png?v5","rowboat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a3.png?v5","ru":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1f7-1f1fa.png?v5","rugby_football":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c9.png?v5","runner":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c3.png?v5","running":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c3.png?v5","running_shirt_with_sash":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3bd.png?v5","sa":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f202.png?v5","sagittarius":"https://assets-cdn.github.com/images/icons/emoji/unicode/2650.png?v5","sailboat":"https://assets-cdn.github.com/images/icons/emoji/unicode/26f5.png?v5","sake":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f376.png?v5","sandal":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f461.png?v5","santa":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f385.png?v5","satellite":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4e1.png?v5","satisfied":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f606.png?v5","saxophone":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b7.png?v5","school":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3eb.png?v5","school_satchel":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f392.png?v5","scissors":"https://assets-cdn.github.com/images/icons/emoji/unicode/2702.png?v5","scorpius":"https://assets-cdn.github.com/images/icons/emoji/unicode/264f.png?v5","scream":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f631.png?v5","scream_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f640.png?v5","scroll":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4dc.png?v5","seat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ba.png?v5","secret":"https://assets-cdn.github.com/images/icons/emoji/unicode/3299.png?v5","see_no_evil":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f648.png?v5","seedling":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f331.png?v5","seven":"https://assets-cdn.github.com/images/icons/emoji/unicode/0037-20e3.png?v5","shaved_ice":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f367.png?v5","sheep":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f411.png?v5","shell":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f41a.png?v5","ship":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a2.png?v5","shipit":"https://assets-cdn.github.com/images/icons/emoji/shipit.png?v5","shirt":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f455.png?v5","shit":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a9.png?v5","shoe":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45e.png?v5","shower":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6bf.png?v5","signal_strength":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f6.png?v5","six":"https://assets-cdn.github.com/images/icons/emoji/unicode/0036-20e3.png?v5","six_pointed_star":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52f.png?v5","ski":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3bf.png?v5","skull":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f480.png?v5","sleeping":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f634.png?v5","sleepy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f62a.png?v5","slot_machine":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3b0.png?v5","small_blue_diamond":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f539.png?v5","small_orange_diamond":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f538.png?v5","small_red_triangle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f53a.png?v5","small_red_triangle_down":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f53b.png?v5","smile":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f604.png?v5","smile_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f638.png?v5","smiley":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f603.png?v5","smiley_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f63a.png?v5","smiling_imp":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f608.png?v5","smirk":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f60f.png?v5","smirk_cat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f63c.png?v5","smoking":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6ac.png?v5","snail":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f40c.png?v5","snake":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f40d.png?v5","snowboarder":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c2.png?v5","snowflake":"https://assets-cdn.github.com/images/icons/emoji/unicode/2744.png?v5","snowman":"https://assets-cdn.github.com/images/icons/emoji/unicode/26c4.png?v5","sob":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f62d.png?v5","soccer":"https://assets-cdn.github.com/images/icons/emoji/unicode/26bd.png?v5","soon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f51c.png?v5","sos":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f198.png?v5","sound":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f509.png?v5","space_invader":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f47e.png?v5","spades":"https://assets-cdn.github.com/images/icons/emoji/unicode/2660.png?v5","spaghetti":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f35d.png?v5","sparkle":"https://assets-cdn.github.com/images/icons/emoji/unicode/2747.png?v5","sparkler":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f387.png?v5","sparkles":"https://assets-cdn.github.com/images/icons/emoji/unicode/2728.png?v5","sparkling_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f496.png?v5","speak_no_evil":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f64a.png?v5","speaker":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f508.png?v5","speech_balloon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ac.png?v5","speedboat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a4.png?v5","squirrel":"https://assets-cdn.github.com/images/icons/emoji/shipit.png?v5","star":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b50.png?v5","star2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f31f.png?v5","stars":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f320.png?v5","station":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f689.png?v5","statue_of_liberty":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f5fd.png?v5","steam_locomotive":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f682.png?v5","stew":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f372.png?v5","straight_ruler":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4cf.png?v5","strawberry":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f353.png?v5","stuck_out_tongue":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f61b.png?v5","stuck_out_tongue_closed_eyes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f61d.png?v5","stuck_out_tongue_winking_eye":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f61c.png?v5","sun_with_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f31e.png?v5","sunflower":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f33b.png?v5","sunglasses":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f60e.png?v5","sunny":"https://assets-cdn.github.com/images/icons/emoji/unicode/2600.png?v5","sunrise":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f305.png?v5","sunrise_over_mountains":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f304.png?v5","surfer":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c4.png?v5","sushi":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f363.png?v5","suspect":"https://assets-cdn.github.com/images/icons/emoji/suspect.png?v5","suspension_railway":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f69f.png?v5","sweat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f613.png?v5","sweat_drops":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a6.png?v5","sweat_smile":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f605.png?v5","sweet_potato":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f360.png?v5","swimmer":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ca.png?v5","symbols":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f523.png?v5","syringe":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f489.png?v5","tada":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f389.png?v5","tanabata_tree":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f38b.png?v5","tangerine":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f34a.png?v5","taurus":"https://assets-cdn.github.com/images/icons/emoji/unicode/2649.png?v5","taxi":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f695.png?v5","tea":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f375.png?v5","telephone":"https://assets-cdn.github.com/images/icons/emoji/unicode/260e.png?v5","telephone_receiver":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4de.png?v5","telescope":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f52d.png?v5","tennis":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3be.png?v5","tent":"https://assets-cdn.github.com/images/icons/emoji/unicode/26fa.png?v5","thought_balloon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ad.png?v5","three":"https://assets-cdn.github.com/images/icons/emoji/unicode/0033-20e3.png?v5","thumbsdown":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44e.png?v5","thumbsup":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44d.png?v5","ticket":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ab.png?v5","tiger":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f42f.png?v5","tiger2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f405.png?v5","tired_face":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f62b.png?v5","tm":"https://assets-cdn.github.com/images/icons/emoji/unicode/2122.png?v5","toilet":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6bd.png?v5","tokyo_tower":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f5fc.png?v5","tomato":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f345.png?v5","tongue":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f445.png?v5","top":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f51d.png?v5","tophat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3a9.png?v5","tractor":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f69c.png?v5","traffic_light":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a5.png?v5","train":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f68b.png?v5","train2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f686.png?v5","tram":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f68a.png?v5","triangular_flag_on_post":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a9.png?v5","triangular_ruler":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4d0.png?v5","trident":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f531.png?v5","triumph":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f624.png?v5","trolleybus":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f68e.png?v5","trollface":"https://assets-cdn.github.com/images/icons/emoji/trollface.png?v5","trophy":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3c6.png?v5","tropical_drink":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f379.png?v5","tropical_fish":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f420.png?v5","truck":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f69a.png?v5","trumpet":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ba.png?v5","tshirt":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f455.png?v5","tulip":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f337.png?v5","turtle":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f422.png?v5","tv":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4fa.png?v5","twisted_rightwards_arrows":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f500.png?v5","two":"https://assets-cdn.github.com/images/icons/emoji/unicode/0032-20e3.png?v5","two_hearts":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f495.png?v5","two_men_holding_hands":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f46c.png?v5","two_women_holding_hands":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f46d.png?v5","u5272":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f239.png?v5","u5408":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f234.png?v5","u55b6":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f23a.png?v5","u6307":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f22f.png?v5","u6708":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f237.png?v5","u6709":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f236.png?v5","u6e80":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f235.png?v5","u7121":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f21a.png?v5","u7533":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f238.png?v5","u7981":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f232.png?v5","u7a7a":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f233.png?v5","uk":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1ec-1f1e7.png?v5","umbrella":"https://assets-cdn.github.com/images/icons/emoji/unicode/2614.png?v5","unamused":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f612.png?v5","underage":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f51e.png?v5","unlock":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f513.png?v5","up":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f199.png?v5","us":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f1fa-1f1f8.png?v5","v":"https://assets-cdn.github.com/images/icons/emoji/unicode/270c.png?v5","vertical_traffic_light":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6a6.png?v5","vhs":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4fc.png?v5","vibration_mode":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f3.png?v5","video_camera":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4f9.png?v5","video_game":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3ae.png?v5","violin":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f3bb.png?v5","virgo":"https://assets-cdn.github.com/images/icons/emoji/unicode/264d.png?v5","volcano":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f30b.png?v5","vs":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f19a.png?v5","walking":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6b6.png?v5","waning_crescent_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f318.png?v5","waning_gibbous_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f316.png?v5","warning":"https://assets-cdn.github.com/images/icons/emoji/unicode/26a0.png?v5","watch":"https://assets-cdn.github.com/images/icons/emoji/unicode/231a.png?v5","water_buffalo":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f403.png?v5","watermelon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f349.png?v5","wave":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f44b.png?v5","wavy_dash":"https://assets-cdn.github.com/images/icons/emoji/unicode/3030.png?v5","waxing_crescent_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f312.png?v5","waxing_gibbous_moon":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f314.png?v5","wc":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6be.png?v5","weary":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f629.png?v5","wedding":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f492.png?v5","whale":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f433.png?v5","whale2":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f40b.png?v5","wheelchair":"https://assets-cdn.github.com/images/icons/emoji/unicode/267f.png?v5","white_check_mark":"https://assets-cdn.github.com/images/icons/emoji/unicode/2705.png?v5","white_circle":"https://assets-cdn.github.com/images/icons/emoji/unicode/26aa.png?v5","white_flower":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4ae.png?v5","white_large_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/2b1c.png?v5","white_medium_small_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/25fd.png?v5","white_medium_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/25fb.png?v5","white_small_square":"https://assets-cdn.github.com/images/icons/emoji/unicode/25ab.png?v5","white_square_button":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f533.png?v5","wind_chime":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f390.png?v5","wine_glass":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f377.png?v5","wink":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f609.png?v5","wolf":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f43a.png?v5","woman":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f469.png?v5","womans_clothes":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f45a.png?v5","womans_hat":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f452.png?v5","womens":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f6ba.png?v5","worried":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f61f.png?v5","wrench":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f527.png?v5","x":"https://assets-cdn.github.com/images/icons/emoji/unicode/274c.png?v5","yellow_heart":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f49b.png?v5","yen":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4b4.png?v5","yum":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f60b.png?v5","zap":"https://assets-cdn.github.com/images/icons/emoji/unicode/26a1.png?v5","zero":"https://assets-cdn.github.com/images/icons/emoji/unicode/0030-20e3.png?v5","zzz":"https://assets-cdn.github.com/images/icons/emoji/unicode/1f4a4.png?v5"};

    const TOKEN_KEY = 'hovercard-token';
    let token = '';
    let chrome = window.chrome;

    let cardOptions = {
        delay: 200
    };

    // Revert to localStorage
    // May switch back to chrome.storage when options are properly designed
    // In Firefox options are not so flexible so keep tokens in localStorage
    if (chrome && chrome.storage) {
        let storage = chrome.storage.sync || chrome.storage.local;
        storage.get({token: '', delay: 0}, item => {
            token = item.token;
            if (token) {
                localStorage.setItem(TOKEN_KEY, token);
                storage.remove('token');
            } else {
                token = localStorage.getItem(TOKEN_KEY);
            }

            // Other options
            let delay = parseFloat(item.delay);
            if (!isNaN(delay)) {
                cardOptions.delay = delay;
            }
            extract();
        });
    } else {
        token = localStorage.getItem(TOKEN_KEY);

        // Firefox options
        if (self.port) {
            self.port.on('prefs', ({ delay }) => {
                if (!isNaN(delay)) {
                    cardOptions.delay = delay;
                }
                extract();
            })
        } else {
            extract();
        }

    }
});
