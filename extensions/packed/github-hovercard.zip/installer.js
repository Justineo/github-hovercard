(() => {
  document.body.setAttribute('data-github-hovercard', 'true');
})();
